#include<stdio.h>

int main()
{
	int kor, eng, math;

	math = 80;
	eng = 100;
	kor = 90;

	printf("This program print report card.\n");

	printf("Korean : %d\n", kor);
	printf("English : %d\n", eng);
	printf("Math : %d\n", math);
	return 0;
}
